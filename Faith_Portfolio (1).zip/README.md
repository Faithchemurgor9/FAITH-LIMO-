# Faith Chemurgor Limo - Portfolio 🌐

Welcome to my personal portfolio website! This project showcases my skills, projects, and learning journey in **Data, AI, Python, and Virtual Assistance**.  
Built with **HTML, CSS, and Bootstrap**, it’s fully responsive and easy to navigate.

## 🔹 Features
- Responsive design with Bootstrap 5
- Smooth scrolling navigation
- Resume section with downloadable CV
- Projects section linking to Kaggle and GitHub
- Lab challenges showcasing hands-on learning
- Contact section with direct links (LinkedIn, GitHub, Kaggle, Email)

## 🔹 How to run locally
1. Clone the repository:
```
git clone https://github.com/Faithchemurgor9/portfolio.git
cd portfolio
```
2. Open `index.html` in your browser.

## 🔹 Contact
- 📧 Email: flimo9129@gmail.com  
- 🔗 LinkedIn: [faith-limo-chemurgor](https://www.linkedin.com/in/faith-limo-chemurgor)  
- 🐙 GitHub: [Faithchemurgor9](https://github.com/Faithchemurgor9)  
- 📊 Kaggle: [faithchemurgorlimo](https://www.kaggle.com/faithchemurgorlimo)
